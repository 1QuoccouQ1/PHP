<?php
    $u = $_POST["user"];
    $e = $_POST["email"];
    $p = $_POST["pass"];    

    echo $u;
    echo "<br>";
    echo $p;
    echo "<br>";
    echo $e;
?>