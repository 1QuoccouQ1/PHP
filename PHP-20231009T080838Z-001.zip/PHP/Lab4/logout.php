<?php
    session_start();
    session_destroy();
    header("Location: login.php");  //redirect to login page after logout
    exit();

?>