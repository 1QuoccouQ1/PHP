<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="addpro.css">
</head>
<body>
    <div class="container">
        <form action="">
            <table>
                <tr>
                    <td>
                        Product Name <br>
                        <input type="text" name="product_name" id = "product_id ">
                    </td>
                </tr>
                <tr>
                    <td>
                    Description <br>
                        <input type="text" name="product_name" id = "product_id ">
                    </td>
                </tr>
                <tr>
                    <td>
                    Price <br>
                        <input type="text" name="product_name" id = "product_id ">
                    </td>
                </tr>
                <tr>
                    <td>
                    Category <br>
                    <select  name="category" id = "category" style="width: 171px;">
                    
                        <option value="laptip">Laptop</option>
                        <option value="Phone">Phone</option>
                        
                        </select>
                    </td>
                </tr>
                <tr>
                    <td>
                    Room Image <br>
                        <input type="file" name="image_product" id = "image_product ">
                    </td>
                </tr>
                <tr>
                    <td>
                        <input type="submit" name="Save" id = "Save" valua="Save" >
                    </td>
                </tr>
            </table>
        </form>
    </div>
</body>
</html>