<?php
    session_start();
    if(isset($_SESSION["user"])){
        echo "Welcome" . $_SESSION["user"];
        //echo "<a href='logout.php'>Logout</a>";
        




    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <a href="logout_dk.php">Logout </a>
    
</body>
</html>