<!-- // bai1 -->
<?php
    echo "Hello <br>";
    echo ("Hello <br>");
    echo "Hello World <br>";
    echo "Hello", "World";
?>
<!-- // bai2 -->
<?php
    $str="hello string";
    $x=200;
    $y=44.6;
    echo "string is: $str <br>";
    echo "interger is : $x <br>";
    echo "float is : $y <br>";
?>
<!-- // bai3 -->
<?php
    $color = "red";
    echo "my car is : ".$color."<br>";
    echo "my house is : ".$COLOR."<br>";
    echo "my boat is : ".$coLOR."<br>";
    ?>